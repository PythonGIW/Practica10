Para poder realizar pruebas en esta práctica debemos ejecutar los siguientes comandos en MongoDB:
--Creamos la base de datos
use giw
--Cambiamos a giw
switch giw
--Creamos nuestra colección users
db.createCollection("users")